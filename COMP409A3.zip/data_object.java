public class data_object{
  String value;
  data_object(String value){
    this.value=value;
  }
  
  void set_object(String value){
    this.value=value;
  }
  
  
}